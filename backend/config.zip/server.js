const express = require("express");
const cors = require("cors");
require("dotenv").config();

const db = require("./config/db");

const authRoutes = require("./routes/authRoutes");
const productRoutes = require("./routes/productRoutes");

const app = express();

// =======================
// Middlewares
// =======================
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// =======================
// Static Folder (Images)
// =======================
app.use("/uploads", express.static("uploads"));

// =======================
// API Routes
// =======================
app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);

// =======================
// Test Route
// =======================
app.get("/", (req, res) => {
    res.status(200).json({
        success: true,
        message: "🚀 Chumbak Art Gallery Backend Running..."
    });
});

// =======================
// Database Connection Test
// =======================
db.query("SELECT 1", (err) => {
    if (err) {
        console.log("❌ MySQL Connection Failed");
        console.log(err.message);
    } else {
        console.log("✅ MySQL Connected Successfully");
    }
});

// =======================
// Start Server
// =======================
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});