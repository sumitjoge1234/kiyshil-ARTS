// Chumbak Art frontend demo. Replace this WhatsApp number with the client's number.
const API_URL = "http://localhost:5000/api/products";
const WHATSAPP_NUMBER = "918263089641";
const defaultProducts = [
 {id:1,name:"Floral Elephant Painting",category:"Paintings",price:1499,old:1999,emoji:"🐘",description:"A vibrant hand-painted folk art piece to brighten your walls."},
 {id:2,name:"Artistic Bottle Decor",category:"Home Decor",price:799,old:999,emoji:"🏺",description:"Colourful decorative bottle, handmade with love."},
 {id:3,name:"Handpainted Cushion Cover",category:"Handmade Crafts",price:699,old:999,emoji:"🪡",description:"Bring a cheerful touch to your living space."},
 {id:4,name:"Handmade Wall Hanging",category:"Wall Decor",price:599,old:799,emoji:"🪷",description:"A beautiful handmade hanging for your home."},
 {id:5,name:"Decorative Lantern",category:"Home Decor",price:899,old:1199,emoji:"🏮",description:"Warm decorative lantern for cosy evenings."},
 {id:6,name:"Handpainted Jewellery Box",category:"Handmade Crafts",price:749,old:949,emoji:"🎁",description:"Store your little treasures in a colourful box."},
 {id:7,name:"Mandala Wall Art",category:"Wall Decor",price:699,old:999,emoji:"🌸",description:"Intricate mandala-inspired wall decoration."},
 {id:8,name:"DIY Art Kit",category:"Art Supplies",price:849,old:999,emoji:"🎨",description:"Everything you need to start creating."}
];
function getProducts(){try{return JSON.parse(localStorage.getItem("chumbak_products"))||defaultProducts}catch(e){return defaultProducts}}
function saveProducts(p){localStorage.setItem("chumbak_products",JSON.stringify(p))}
function getCart(){try{return JSON.parse(localStorage.getItem("chumbak_cart"))||[]}catch(e){return []}}
function saveCart(c){localStorage.setItem("chumbak_cart",JSON.stringify(c));updateCartCount()}
function money(n){return "₹"+Number(n).toLocaleString("en-IN")}
function updateCartCount(){let el=document.getElementById("cart-count");if(el)el.textContent=getCart().reduce((s,x)=>s+x.qty,0)}
function productCard(p){return `<article class="product-card"><div class="product-image">${p.image?`<img src="${p.image}" alt="${p.name}">`:p.emoji||"🎨"}<span class="discount">HANDMADE</span><button class="heart" onclick="toggleWishlist(${p.id},this)">♡</button></div><div class="product-info"><h3>${p.name}</h3><div><span class="price">${money(p.price)}</span> <span class="old-price">${money(p.old||p.price)}</span></div><div class="product-actions"><a class="small-btn" href="product.html?id=${p.id}">View Details</a><button class="small-btn" onclick="addToCart(${p.id})">Add to Cart</button></div></div></article>`}
async function renderFeatured() {

    const container = document.getElementById("featured-products");

    if (!container) return;

    try {

        const response = await fetch(API_URL);

        const data = await response.json();

        if (!data.success) {

            container.innerHTML = "<p>No Products Found</p>";

            return;
        }

        const products = data.products;

        container.innerHTML = "";

        products.slice(0, 4).forEach(product => {

            container.innerHTML += `

            <article class="product-card">

                <div class="product-image">

                    <img
                        src="http://localhost:5000/uploads/${product.image}"
                        alt="${product.title}"
                    >

                    <span class="discount">
                        HANDMADE
                    </span>

                </div>

                <div class="product-info">

                    <h3>${product.title}</h3>

                    <div>

                        <span class="price">

                            ₹${product.price}

                        </span>

                    </div>

                    <div class="product-actions">

                        <a
                            class="small-btn"
                            href="product.html?id=${product.id}"
                        >
                            View Details
                        </a>

                    </div>

                </div>

            </article>

            `;

        });

    }

    catch (error) {

        console.log(error);

        container.innerHTML = "<p>Server Error</p>";

    }

}
function renderShop(){let el=document.getElementById("all-products");if(!el)return;let products=getProducts();let params=new URLSearchParams(location.search);let cat=params.get("category");if(cat)document.querySelectorAll('.filters input[type=checkbox]').forEach(x=>{if(x.value.toLowerCase()===cat.toLowerCase())x.checked=true});filterProducts()}
function filterProducts(){let el=document.getElementById("all-products");if(!el)return;let selected=[...document.querySelectorAll('.filters input:checked')].map(x=>x.value);let max=document.getElementById("price-filter")?.value||"all";let sort=document.getElementById("sort-filter")?.value||"popular";let p=getProducts().filter(x=>(!selected.length||selected.includes(x.category))&&(max==="all"||x.price<Number(max)));if(sort==="low")p.sort((a,b)=>a.price-b.price);if(sort==="high")p.sort((a,b)=>b.price-a.price);document.getElementById("result-count").textContent=`Showing ${p.length} products`;el.innerHTML=p.length?p.map(productCard).join(""):'<div class="empty-state">No products found. Try another filter.</div>'}
function addToCart(id){let p=getProducts().find(x=>x.id===id);if(!p)return;let c=getCart(),item=c.find(x=>x.id===id);if(item)item.qty++;else c.push({id:p.id,name:p.name,price:p.price,qty:1,emoji:p.emoji,image:p.image});saveCart(c);alert("Added to cart!")}
function toggleWishlist(id,btn){let w=JSON.parse(localStorage.getItem("chumbak_wishlist")||"[]");if(w.includes(id)){w=w.filter(x=>x!==id);btn.textContent="♡"}else{w.push(id);btn.textContent="♥"}localStorage.setItem("chumbak_wishlist",JSON.stringify(w))}
function renderProduct(){let el=document.getElementById("product-detail");if(!el)return;let id=Number(new URLSearchParams(location.search).get("id")||1),p=getProducts().find(x=>x.id===id)||getProducts()[0];el.innerHTML=`<div class="detail-grid"><div class="detail-art">${p.image?`<img src="${p.image}" style="width:100%;height:100%;object-fit:cover;border-radius:18px">`:p.emoji||"🎨"}</div><div class="detail-copy"><span class="eyebrow">${p.category}</span><h1>${p.name}</h1><div class="price">${money(p.price)} <span class="old-price">${money(p.old||p.price)}</span></div><p>${p.description||"Beautiful handmade artwork created with love."}</p><p>♡ Handmade with love &nbsp; ✦ Perfect for home décor &nbsp; ✦ Great for gifting</p><label>Quantity <input class="qty" id="detail-qty" type="number" min="1" value="1"></label><br><button class="btn btn-pink" onclick="addDetailToCart(${p.id})">Add to Cart</button> <a class="btn whatsapp" href="#" onclick="orderSingle(${p.id});return false">Order on WhatsApp</a><p class="muted">Free shipping on orders above ₹999 · Easy order confirmation on WhatsApp</p></div></div>`}
function addDetailToCart(id){let qty=Math.max(1,Number(document.getElementById("detail-qty").value)||1),p=getProducts().find(x=>x.id===id),c=getCart(),item=c.find(x=>x.id===id);if(item)item.qty+=qty;else c.push({id:p.id,name:p.name,price:p.price,qty,emoji:p.emoji,image:p.image});saveCart(c);alert("Added to cart!")}
function openWhatsApp(message){let number=WHATSAPP_NUMBER.replace(/\D/g,"");if(number==="91XXXXXXXXXX".replace(/\D/g,"")){alert("Please add the client's WhatsApp number in assets/js/app.js (WHATSAPP_NUMBER).");return}window.open("https://wa.me/"+number+"?text="+encodeURIComponent(message),"_blank")}
function orderSingle(id){let p=getProducts().find(x=>x.id===id),qty=Math.max(1,Number(document.getElementById("detail-qty")?.value)||1);openWhatsApp(`Hello Chumbak Art! I want to order:\\n${p.name}\\nPrice: ${money(p.price)}\\nQuantity: ${qty}\\nTotal: ${money(p.price*qty)}\\nPlease confirm my order.`)}
function renderCart(){let el=document.getElementById("cart-items");if(!el)return;let c=getCart();if(!c.length){el.innerHTML='<div class="empty-state"><div style="font-size:55px">🛍️</div><h3>Your cart is waiting for some art!</h3><a class="btn btn-pink" href="shop.html">Explore Products</a></div>';return}let total=c.reduce((s,x)=>s+x.price*x.qty,0);el.innerHTML=c.map(x=>`<div class="cart-row"><div class="cart-thumb">${x.image?`<img src="${x.image}" style="width:100%;height:100%;object-fit:cover">`:x.emoji||"🎨"}</div><div><b>${x.name}</b><div class="muted">${money(x.price)} each</div></div><div><button onclick="changeQty(${x.id},-1)">−</button> ${x.qty} <button onclick="changeQty(${x.id},1)">+</button></div><button class="remove" onclick="removeCart(${x.id})">✕</button></div>`).join("")+`<div class="cart-total"><span>Total: ${money(total)}</span><button class="btn whatsapp" onclick="checkoutWhatsApp()">Order on WhatsApp →</button></div><p class="muted" style="text-align:right">Your order will be sent to the store on WhatsApp for confirmation.</p>`}
function changeQty(id,d){let c=getCart(),x=c.find(x=>x.id===id);if(x)x.qty+=d;c=c.filter(x=>x.qty>0);saveCart(c);renderCart()}
function removeCart(id){saveCart(getCart().filter(x=>x.id!==id));renderCart()}
function checkoutWhatsApp(){let c=getCart();if(!c.length)return;let total=c.reduce((s,x)=>s+x.price*x.qty,0),lines=c.map(x=>`${x.name} - ${x.qty} x ${money(x.price)} = ${money(x.qty*x.price)}`).join("\\n");openWhatsApp(`Hello Chumbak Art! I would like to place an order:\\n\\n${lines}\\n\\nGrand Total: ${money(total)}\\nPlease confirm availability and delivery details.`)}
function addAdminProduct(e){e.preventDefault();let p=getProducts();p.unshift({id:Date.now(),name:document.getElementById("art-name").value,price:Number(document.getElementById("art-price").value),old:Number(document.getElementById("art-price").value),category:document.getElementById("art-category").value,image:document.getElementById("art-image").value,emoji:"🎨",description:document.getElementById("art-description").value});saveProducts(p);e.target.reset();renderAdminProducts();let count=document.getElementById("admin-product-count");if(count)count.textContent=p.length;alert("Artwork added in this browser demo. Backend database will be connected later.")}
function renderAdminProducts(){let el=document.getElementById("admin-products");if(!el)return;let p=getProducts();el.innerHTML=`<table class="admin-products-table"><thead><tr><th>Artwork</th><th>Category</th><th>Price</th><th>Action</th></tr></thead><tbody>${p.map(x=>`<tr><td>${x.name}</td><td>${x.category}</td><td>${money(x.price)}</td><td><button onclick="deleteAdminProduct(${x.id})">Delete</button></td></tr>`).join("")}</tbody></table>`}
function deleteAdminProduct(id){if(!confirm("Delete this artwork?"))return;saveProducts(getProducts().filter(x=>x.id!==id));renderAdminProducts();let c=document.getElementById("admin-product-count");if(c)c.textContent=getProducts().length}
function toggleMenu(){document.getElementById("nav")?.classList.toggle("open")}
document.addEventListener("DOMContentLoaded",()=>{updateCartCount();renderFeatured();renderShop();renderProduct();renderCart();renderAdminProducts();let f=document.getElementById("add-product-form");if(f)f.addEventListener("submit",addAdminProduct);let c=document.getElementById("admin-product-count");if(c)c.textContent=getProducts().length});