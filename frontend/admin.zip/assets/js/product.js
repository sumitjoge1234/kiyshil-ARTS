const API_URL = "http://localhost:5000/api/products";

async function loadProducts() {
    try {
        const response = await fetch(API_URL);
        const data = await response.json();

        const container = document.getElementById("featured-products");

        container.innerHTML = "";

        data.products.forEach(product => {
            container.innerHTML += `
                <div class="product-card">

                    <img src="http://localhost:5000/uploads/${product.image}" alt="${product.name}">

                    <h3>${product.name}</h3>

                    <p>₹${product.price}</p>

                    <button>View Details</button>

                </div>
            `;
        });

    } catch (error) {
        console.log(error);
    }
}

loadProducts();